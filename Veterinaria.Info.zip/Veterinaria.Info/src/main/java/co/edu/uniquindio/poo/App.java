package co.edu.uniquindio.poo;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
      
      var veterinaria = new Veterinaria ("Bob", Especie.PERRO, Raza.BULLDOG, (byte) 2, Genero.MACHO, Color.BLANCO, 18.6f);
      System.out.println(veterinaria.toString()); 
    }
    
}
