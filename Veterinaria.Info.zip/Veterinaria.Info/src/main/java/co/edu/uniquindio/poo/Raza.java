package co.edu.uniquindio.poo;

public enum Raza {
    BULLDOG,
    SALCHICHA,
    GOLDEN,
    PITBULL,
    PASTOR
}
