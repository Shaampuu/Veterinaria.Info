package co.edu.uniquindio.poo;

/* 
 * Ejercicio: 
 * En una veterinaria llamada "Amigos Peludos", el Dr. Martínez busca implementar un sistema de gestión de pacientes para simplificar
 *  el registro y seguimiento de los animales atendidos. Para ello, este sistema almacenará la información detallada de cada mascota, 
 * incluyendo nombre, especie, raza, edad, género, color y  peso.
 * 
*@since 03/03/2024
 *@author Jorge Simon Nieto Celemin
 * Licencia GNU/GPL V3.0 (https://raw.githubusercontent.com/grid-uq/poo/main/LICENSE) 
 */


public class Veterinaria {
    private String nombre;
    private Especie especie;
    private Raza raza;
    private byte edad;
    private Genero genero;
    private Color color;
    private float peso;

    public Veterinaria(String nombre, Especie especie, Raza raza, byte edad, Genero genero, Color color,
            float peso) {

        assert nombre != null && !nombre.isBlank();
        assert especie !=null:"es necesario la especie" ;
        assert raza!=null:"es necesario la raza";
        assert genero!=null: "es necesario el genero";
        assert color!=null: "es necesario el color";
        assert edad>=0: "la edad no puede ser negativa";
        assert peso >=0f: "el peso no puede ser nevativo";

        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.edad = edad;
        this.genero = genero;
        this.color = color;
        this.peso = peso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Especie getEspecie() {
        return especie;
    }

    public void setEspecie(Especie especie) {
        this.especie = especie;
    }

    public Raza getRaza() {
        return raza;
    }

    public void setRaza(Raza raza) {
        this.raza = raza;
    }

    public byte getEdad() {
        return edad;
    }

    public void setEdad(byte edad) {
        this.edad = edad;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "Mascota" + 
                "\nNombre:" + nombre+ 
                "\nEspecie:" + especie +
                "\nRaza:" + raza +
                "\nEdad:" + edad +
                "\nGenero:" + genero +
                "\ncolor:" + color +
                "\nPeso en kg:" + peso ;

        
    }

}
