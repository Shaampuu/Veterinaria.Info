package co.edu.uniquindio.poo;

public enum Color {
    BLANCO,
    NEGRO,
    CAFE,
    MANCHAS,
    NARANJA
}
