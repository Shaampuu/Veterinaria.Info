package co.edu.uniquindio.poo;

public enum Genero {
    MACHO,
    HEMBRA
}
