package co.edu.uniquindio.poo;

public enum Especie {
    PERRO,
    GATO
    
}
